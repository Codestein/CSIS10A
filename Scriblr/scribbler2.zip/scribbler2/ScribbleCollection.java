import objectdraw.*;
import java.awt.*;

// this class contains an array of Scribbles
public class ScribbleCollection {

    // private int number of scribbles
    // private Scribble[] scribbles = new Scribble[MAX];
    
    /*
     * add a scribble to the array
     * if the array is full, create and throw a RuntimeException.
     */
    public void addScribble (Scribble s){
    }
    
    /*
     * return the scribble that contains the input location
     * return null if no scribble contains the location
     */
    public Scribble contains (Location pt){
        return null;
    }
    
    /*
     * remove the last scribble from the canvas
     * remove the scribble from the collection array
     * if there are no scribbles, then do nothing.
     */
    public void removeLast(){
    }
}