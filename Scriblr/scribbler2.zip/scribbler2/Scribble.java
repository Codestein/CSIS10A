import objectdraw.*;
import java.awt.*;

// this class holds an array of line segments
// that make up one scribble
public class Scribble {

    private static final int MAX_LINES=10000;   // size of array
    
    private int numberLines = 0;                // count of line segments in scribble
    private Line[] lines = new Line[MAX_LINES]; // array to hold line segments
    
    public void addLine(Line segment){
        if (numberLines==MAX_LINES){
            // too many lines
            System.out.println("ERROR: MAX LINES EXCEEDED");
            throw new RuntimeException("MAX LINES EXCEEDED");
        } else {
            lines[numberLines]=segment;
            numberLines++;
        }
    }
    
    public boolean contains(Location pt){
        for (int i=0; i<numberLines; i++){
            if (lines[i].contains(pt)){
                return true;
            }
        }
        return false;
    }
    
    public void move(double dx, double dy){
        for (int i=0; i<numberLines; i++){
            lines[i].move(dx, dy);
        }
    } 
    
}